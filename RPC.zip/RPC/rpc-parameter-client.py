#import packages
import xmlrpc.client

#Mendefinisikan koneksinya ke server 
proxy = xmlrpc.client.ServerProxy("http://localhost:8000/")

#Panggil Eksekusi function di server
hargabarang = int(input('Masukkan harga barang: '))
hitungDiskon = proxy.hitungDiskon(hargabarang)

#menampilkan hasil 
print("Total dari diskon 45% dari harga barang",hargabarang , "Rp :", hitungDiskon ,"Rp")