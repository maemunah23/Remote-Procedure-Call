# Memanggil library/package RPC
from xmlrpc.server import SimpleXMLRPCServer

#Membuat menu untuk client / membuat proses untuk client
#membuat proses yang akan di eksekusi
def hitungDiskon (harga):
    data = harga * (45/100)
    hasil = harga - data
    return hasil 

#Inisialisasi runtime
server = SimpleXMLRPCServer(("localhost", 8000))

#mengeluarkan status server
print("Server telah berjalan...")

#daftarkan proses yang bisa di eksekusi client
server.register_function(hitungDiskon)

#Jalankan & setting server listening forever
server.serve_forever()